mkdir ~/.visual_servo_controller
cp ./servoset.lsp ~/.visual_servo_controller
