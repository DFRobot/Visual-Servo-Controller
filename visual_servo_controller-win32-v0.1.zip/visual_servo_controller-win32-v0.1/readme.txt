/*******************************************************************************
 * Copyright (C) 2014 DFRobot                                                  *
 *                                                                             *
 * visual servo controller, This software provides a easy way to control servo *
 *                                                                             *
 * This file is part of the visual servo controller.                           *
 * visual servo controller is free software: you can redistribute it and/or    *
 * modify it under the terms of the GNU General Public License as              *
 * published by the Free Software Foundation, either version 3 of              *
 * the License, or any later version.                                          *
 *                                                                             *
 * visual servo controller is distributed in the hope that it will be useful,  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public                   *
 * License along with visual servo controller. If not, see                     *
 * <http://www.gnu.org/licenses/>.                                             *
 *                                                                             *
 *  DFRobot-A great source for opensource hardware and robot.                  *
 *	DFRobot official website:  http://www.dfrobot.com                          *
 ******************************************************************************/
